<!DOCTYPE html>
<html lang="en">
<head>
<title>Using a link with event handler</title>
<style>
	h3 {color:#FF0000; font-type:italic; text-align:center;}
</style>
</head>
<body>

 <h3>A simple PHP code showing a message</h3>

 <p>

 <?php
 //Command print to print a message
 /*The following command will print
 Our frist PHP code on the screen */

 print ("Our first PHP code!");

 ?>
 </p>
</body>
</html>